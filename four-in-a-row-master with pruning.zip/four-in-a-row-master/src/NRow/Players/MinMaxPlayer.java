package NRow.Players;

import NRow.Board;
import NRow.Game;
import NRow.Heuristics.Heuristic;
import java.util.ArrayList;

public class MinMaxPlayer extends PlayerController {
    private int depth;

    public MinMaxPlayer(int playerId, int gameN, int depth, Heuristic heuristic) {
        super(playerId, gameN, heuristic);
        this.depth = depth;
        // You can add functionality which runs when the player is first created (before
        // the game starts)
    }

    /**
     * Implement this method yourself!
     * 
     * @param board the current board
     * @return column integer the MinMaxplayer chose using the MinMax algorithm
     */
    @Override
    public int makeMove(Board board) {

        int maxValue = Integer.MIN_VALUE; //maxValue-set to Lowest to start
        int maxMove = 0; // maxMove tracks what column should be played next
        for (int i = 0; i < board.width; i++) { // for each of the possible moves
            if (board.isValid(i)) { // checks if the move is valid 
                Board newBoard = board.getNewBoard(i, playerId); // Get a new board resulting from that move
                int value = MinMax(newBoard, 3 - playerId, Integer.MIN_VALUE, Integer.MAX_VALUE, depth - 1); //Then find the best move by using the MinMax algorithm
                
                if (value > maxValue) {
                    System.out.println("UPDATING val = " + value + ", FROM maxVal = " + maxValue);
                    maxMove = i;
                    maxValue = value;
                    System.out.println("NewMaxVal = " + maxValue);
                }
             //Note: use maxMove and check if that is valid.    
            }

        }
        System.out.println("finalMaxVal = " + maxValue);
        System.out.println("opponent move:" + maxMove);
        return maxMove;
    }

    /**
     * MinMax Algorithm without Alpha-beta Pruning
     * 
     * @param board the newBoard from the makeMove function
     * @param currentplayer the playerId to alternate between when the algorithm should minimize and when it should maximize
     * @param depth the depth of the search algorithm, how many steps ahead should it take into account when evaluating the next best possible move
     * 
     * @return the Min value if minimizing the opponent and the Max value if maximizing own move. 
     */
    private int MinMax(Board board, int currentPlayer, int depth) {
        if (depth == 0 || board.isOver()) {
            return heuristic.evaluateBoard(playerId, board);
        }

        if (currentPlayer == playerId) {
            int maxValue = Integer.MIN_VALUE;
            for (int i = 0; i < board.width; i++) {
                if (board.isValid(i)) {

                    Board newBoard = board.getNewBoard(i, currentPlayer);
                    int value1 = MinMax(newBoard, 3 - currentPlayer, depth - 1);

                    maxValue = Math.max(maxValue, value1);

                }
            }
            // System.out.println(board);
            // System.out.println("MaxVal:" + maxValue);
            System.out.print("Max: ");
            System.out.print(maxValue + " ");
            return maxValue;
        } else {
            // System.out.println(board);

            // System.out.print("min:");
            int minValue = Integer.MAX_VALUE;
            for (int i = 0; i < board.width; i++) {
                if (board.isValid(i)) {

                    Board newBoard = board.getNewBoard(i, currentPlayer);
                    int value2 = MinMax(newBoard, 3 - currentPlayer, depth - 1);
                    // System.out.print(value2 + " ");
                    minValue = Math.min(minValue, value2);
                }
            }
            // System.out.println(board);
            System.out.print("Min: ");
            System.out.print(minValue + " ");
            return minValue;

        }
    }

       /**
     * MinMax Algorithm without Alpha-beta Pruning
     * 
     * @param board the newBoard from the makeMove function
     * @param currentplayer the playerId to alternate between when the algorithm should minimize and when it should maximize
     * @param depth the depth of the search algorithm, how many steps ahead should it take into account when evaluating the next best possible move
     * @param alpha
     * @param beta
     * 
     * @return the Min value if minimizing the opponent and the Max value if maximizing own move. 
     */

    private int MinMax(Board board, int currentPlayer, int alpha, int beta, int depth) {
        if (depth == 0 || board.isOver()) {
            return heuristic.evaluateBoard(playerId, board);
        }

        if (currentPlayer == playerId) {
            int maxValue = Integer.MIN_VALUE;
            for (int i = 0; i < board.width; i++) {
                if (board.isValid(i)) {

                    Board newBoard = board.getNewBoard(i, currentPlayer);
                    int value1 = MinMax(newBoard, 3 - currentPlayer, alpha, beta,  depth - 1);
                    maxValue = Math.max(maxValue, value1);
                    alpha = Math.max(alpha, value1);
                    if (beta <= alpha) {
                        break;
                    }
                }
            }
            // System.out.println(board);
            // System.out.println("MaxVal:" + maxValue);
            System.out.print("Max: ");
            System.out.print(maxValue + " ");
            return maxValue;
        } else {
            // System.out.println(board);

            // System.out.print("min:");
            int minValue = Integer.MAX_VALUE;
            for (int i = 0; i < board.width; i++) {
                if (board.isValid(i)) {

                    Board newBoard = board.getNewBoard(i, currentPlayer);
                    int value2 = MinMax(newBoard, 3 - currentPlayer, alpha, beta, depth - 1);
                    // System.out.print(value2 + " ");
                    minValue = Math.min(minValue, value2);
                    beta = Math.min(beta, value2);
                    if (beta <= alpha) {
                        break;
                    }
                }
            }
            // System.out.println(board);
            System.out.print("Min: ");
            System.out.print(minValue + " ");
            return minValue;

        }
    }

    @Override
    public ArrayList<Board> treeSearch(Board board) {
        ArrayList<Board> winningPaths = new ArrayList<Board>();
        // boolean keyWin = true;
        int possibilites = 7;
        for (int i = 0; i < possibilites; i++) {
            if (board.isValid(i)) {
                winningPaths.add(board.getNewBoard(i, playerId));
                board.getNewBoard(i, playerId);
            }

        }

        return winningPaths;
    }

}
