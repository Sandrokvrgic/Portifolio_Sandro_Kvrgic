Finding reported speech in 17th century Italian letters project was made in total of 3 jupyter notebooks and 1 environment. Here I will explain each one of them, and how they should be used, alongside needed imports. I will also explain each document which you will recieve as a part of a zip file. Its worth to note that the dataset was composed out of 725 letters. Its also worth to note that by runing the notebooks, you will create multiple files from the zip folder, these files are provided as we got them from the notebooks, so that you do not need to run all of the notebooks.

We started the project in SorianoCorpus jupyter notebook. This notebook was used to connect to cloud corpus, from which we extracted the data. There is an extensive guide on Github of the whole Soriano project on how to connect to the corpus, and how it should be used, underneath I will provide a link to that repository, all of the information about is stored in a read me file of the repository. In this notebook we learned how to access the data and the nodes, and the main idea at the start was to build the project around this data. As we later learned through some test, this was not really viable as we decided to build the starting model on a subset of all data, namely Italic part of the text. The cloud corpus did not have any markers for Italic data, and therefore we put our focus on working with local dataset, which was sent to us from the project owner, which was essentailly the same text, just spread out over mutliple word documents. For a while we tried to match the Italic parts of the local dataset, with the corpus dataset, so that we could continue working with that corpus dataset, as we considered that nodes could play a crucial part iin our future model, but our efforts did not yield any success. Therefore, we continued our project in ItalicTextSoriano jupyter notebook, and we are providing you with the SorianoCorpus jupyter notebook as proof of our early work, even though it does not hold any value towards the results of the project.

ItalicTextSoriano jupyter notebook is the main notebook of the project. It contains the extraction of italic parts of the text from the local dataset, direct speech regex patterns, labeling system and the TF-IDF + logistical regression  model. It also contains parts where we load the correct labeled data on which the model is trained. This notebook outputs many documents, which I will explain in other part of this document.

Lastly FullTextSoriano juypter notebook, is used to apply the direct speech regex patterns on the full text, providing us with two really usefull documents, full text labeled document, and only reported speech document from all 725 letters.

THE ZIP FILE CONTAINS OTHER DOCUMENTS AS FOLLOWS (I will put *** after really important documents):

FOLDER Soriano_texts *** - original data we got provided by the project owner, was used in FullTextSoriano
FOLDER Soriano_texts2 *** - manualy cleaned data we used for training our model, was used in ItalicTextSoriano
CSV FILE fulltext_sentences_labeled *** - one of the results of our project, all sentences from all letters labeled, not very clean document due to time constraints.
CSV FILE italic_sentences_labeled *** - system labeled data using direct speech regex patterns
CSV FILE italic_sentences_labeledCORRECTED *** - manualy labeled data used for training the model, 2 labels
CSV FILE italic_sentences_labeledCORRECTED2 - iteration of manualy labeled data, needed for next iteration
CSV FILE italic_sentences_labeledCORRECTED3 *** - used for the training of the TF-IDF + logistical regression  model, 3 labels
CSV FILE italic_texts_dataset - extracted italic dataset, without sentence splitting
CSV FILE italic_texts_dataset_cleaned - a cleaned version of italic dataset
CSV FILE only_reported_sentences *** - system labeled sentences for all 725 letters, containing only reported sentences, therefore one of the results of the project

ENVIRONMENT
YAML FILE SorianoEnvironment - environment used in this project, we suggest you to activate this environment by writing conda env create -f SorainoEnvironment.yml in the anaconda terminal

If you decide not to use the environment, you can make your own environment by doing these installs:

pip install blinker==1.9.0
pip install click==8.1.8
pip install contourpy==1.3.1
pip install cycler==0.12.1
pip install flask==3.1.0
pip install fonttools==4.56.0
pip install ftfy==6.3.1
pip install gensim==4.3.3
pip install itsdangerous==2.2.0
pip install joblib==1.4.2
pip install kiwisolver==1.4.8
pip install lxml==5.3.1
pip install markdown==3.7
pip install matplotlib==3.10.1
pip install nltk==3.9.1
pip install numpy==1.26.4
pip install pandas==2.2.3
pip install pillow==11.1.0
pip install pyparsing==3.2.1
pip install python-docx==1.1.2
pip install pytz==2025.1
pip install regex==2024.11.6
pip install scikit-learn==1.6.1
pip install scipy==1.13.1
pip install smart-open==7.1.0
pip install text-fabric==12.6.4
pip install threadpoolctl==3.5.0
pip install tqdm==4.67.1
pip install tzdata==2025.1
pip install werkzeug==3.1.3
pip install wrapt==1.17.2

Lastly, as promised, underneath you can find a link for a Github repository containing the Soriano project, we hope you will enjoy the project!

https://github.com/HuygensING/suriano/tree/main/app

Written by Sandro Kvrgić
 
